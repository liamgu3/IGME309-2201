
#include "Octree.h"
#include "MyEntityManager.h"
using namespace Simplex;

uint Octree::m_uOctantCount = 0; //will store the number of octants instantiated
uint Octree::m_uMaxLevel = 5;//will store the maximum level an octant can go to
uint Octree::m_uIdealEntityCount = 5; //will tell how many ideal Entities this object will contain

Simplex::Octree::Octree(uint a_nMaxLevel, uint a_nIdealEntityCount)
{
	m_uMaxLevel = a_nMaxLevel;
	m_uIdealEntityCount = a_nIdealEntityCount;

	m_pMeshMngr = MeshManager::GetInstance();
	m_pEntityMngr = MyEntityManager::GetInstance();
	
	m_uLevel = a_nMaxLevel;
	m_uChildren = 0;
	m_uID = 0;
	//m_uOctantCount++;

	octantRB = MyRigidBody({ m_v3Min, m_v3Max });

	m_v3Center = vector3(0.0f);
	m_fSize = 70.0f;

	ConstructTree(a_nMaxLevel);
}

Simplex::Octree::Octree(vector3 a_v3Center, float a_fSize)
{
	m_v3Center = a_v3Center;
	m_fSize = a_fSize;
	m_uChildren = 0;

	m_pMeshMngr = Simplex::MeshManager::GetInstance();
	m_pEntityMngr = Simplex::MyEntityManager::GetInstance();

	

	m_v3Min = a_v3Center + vector3(-a_fSize, -a_fSize, -a_fSize);
	m_v3Max = a_v3Center + vector3(a_fSize, a_fSize, a_fSize);

	octantRB = MyRigidBody({ m_v3Min, m_v3Max });
}

Simplex::Octree::Octree(Octree const& other)
{
	m_uID = other.m_uID;
	m_uLevel = other.m_uLevel;
	m_uChildren = other.m_uChildren;

	m_fSize = other.m_fSize;

	m_pMeshMngr = other.m_pMeshMngr;
	m_pEntityMngr = other.m_pEntityMngr;

	m_v3Center = other.m_v3Center;
	m_v3Min = other.m_v3Min;
	m_v3Max = other.m_v3Max;

	m_pParent = other.m_pParent;
	for (int i = 0; i < 8; i++)
	{
		m_pChild[i] = other.m_pChild[i];
	}
	for (int i = 0; i < other.m_EntityList.size(); i++)
	{
		m_EntityList.push_back(other.m_EntityList[i]);
	}

	m_pRoot = other.m_pRoot;

	for (int i = 0; i < other.m_lChild.size(); i++)
	{
		m_lChild.push_back(other.m_lChild[i]);
	}

}

Octree& Simplex::Octree::operator=(Octree const& other)
{
	m_uID = other.m_uID;
	m_uLevel = other.m_uLevel;
	m_uChildren = other.m_uChildren;

	m_fSize = other.m_fSize;

	m_pMeshMngr = other.m_pMeshMngr;
	m_pEntityMngr = other.m_pEntityMngr;

	m_v3Center = other.m_v3Center;
	m_v3Min = other.m_v3Min;
	m_v3Max = other.m_v3Max;

	m_pParent = other.m_pParent;
	for (int i = 0; i < 8; i++)
	{
		m_pChild[i] = other.m_pChild[i];
	}
	for (int i = 0; i < other.m_EntityList.size(); i++)
	{
		m_EntityList.push_back(other.m_EntityList[i]);
	}

	m_pRoot = other.m_pRoot;

	for (int i = 0; i < other.m_lChild.size(); i++)
	{
		m_lChild.push_back(other.m_lChild[i]);
	}

	return *this;
}

Simplex::Octree::~Octree(void)
{
	/*delete m_pParent;
	m_pParent = nullptr;
	{
		delete[] m_pChild;
		for (int i = 0; i < 8; i++)
		{
			m_pChild[i] = nullptr;
		}
	}*/

	KillBranches();

	delete m_pRoot;
	m_pRoot = nullptr;

	/*for (int i = 0; i < m_lChild.size(); i++)
	{
		delete m_lChild[i];
		m_lChild[i] = nullptr;
	}*/
}

void Simplex::Octree::Swap(Octree& other)
{
	m_uID = other.m_uID;
	m_uLevel = other.m_uLevel;
	m_uChildren = other.m_uChildren;

	m_fSize = other.m_fSize;

	m_pMeshMngr = other.m_pMeshMngr;
	m_pEntityMngr = other.m_pEntityMngr;

	m_v3Center = other.m_v3Center;
	m_v3Min = other.m_v3Min;
	m_v3Max = other.m_v3Max;

	m_pParent = other.m_pParent;
	for (int i = 0; i < 8; i++)
	{
		m_pChild[i] = other.m_pChild[i];
	}
	for (int i = 0; i < other.m_EntityList.size(); i++)
	{
		m_EntityList.push_back(other.m_EntityList[i]);
	}

	m_pRoot = other.m_pRoot;

	for (int i = 0; i < other.m_lChild.size(); i++)
	{
		m_lChild.push_back(other.m_lChild[i]);
	}
}

float Simplex::Octree::GetSize(void)
{
	return m_fSize;
}

vector3 Simplex::Octree::GetCenterGlobal(void)
{
	return m_v3Center;
}

vector3 Simplex::Octree::GetMinGlobal(void)
{
	return m_v3Min;
}

vector3 Simplex::Octree::GetMaxGlobal(void)
{
	return m_v3Max;
}

bool Simplex::Octree::IsColliding(uint a_uRBIndex)
{
	if (m_pEntityMngr->GetEntity(a_uRBIndex)->GetRigidBody()->IsColliding(&octantRB))
	{
		return true;
	}
	return false;
}

void Simplex::Octree::Display(uint a_nIndex, vector3 a_v3Color)
{
	
}

void Simplex::Octree::Display(vector3 a_v3Color)
{
	//i need to make the display stuff work
	

	if (m_uChildren != 0)
	{

		for (int i = 0; i < 8; i++)
		{
			m_pChild[i]->Display(a_v3Color);
		}
	}
	else
	{
		m_pMeshMngr->AddWireCubeToRenderList(glm::translate(IDENTITY_M4, m_v3Center) * glm::scale(vector3(m_fSize)), a_v3Color, RENDER_WIRE);
	}
}

void Simplex::Octree::DisplayLeafs(vector3 a_v3Color)
{
}

void Simplex::Octree::ClearEntityList(void)
{
	m_EntityList.clear();
}

void Simplex::Octree::Subdivide(void)
{

}

Octree* Simplex::Octree::GetChild(uint a_nChild)
{
	return m_pChild[a_nChild];
}

Octree* Simplex::Octree::GetParent(void)
{
	return m_pParent;
}

bool Simplex::Octree::IsLeaf(void)
{
	if (m_uChildren == 0)
	{
		return true;
	}
	return false;
}

bool Simplex::Octree::ContainsMoreThan(uint a_nEntities)
{
	if (m_EntityList.size() > a_nEntities)
	{
		return true;
	}
}

void Simplex::Octree::KillBranches(void)
{
	for (int i = 0; i < m_lChild.size(); i++)
	{
		m_lChild[i]->KillBranches();
		delete m_lChild[i];
		m_lChild[i] = nullptr;
	}
	m_uOctantCount = 0;
}

void Simplex::Octree::ConstructTree(uint a_nMaxLevel)
{
	if (a_nMaxLevel > 0)	//constructs all children, then if not at bottom level, constructs children on children
	{
	m_pChild[0] = new Octree(vector3(m_v3Center.x + m_fSize / 4, m_v3Center.y + m_fSize / 4, m_v3Center.z + m_fSize / 4), m_fSize / 2);	//child 1
	m_pChild[1] = new Octree(vector3(m_v3Center.x + m_fSize / 4, m_v3Center.y + m_fSize / 4, m_v3Center.z - m_fSize / 4), m_fSize / 2); //child 2
	m_pChild[2] = new Octree(vector3(m_v3Center.x + m_fSize / 4, m_v3Center.y - m_fSize / 4, m_v3Center.z - m_fSize / 4), m_fSize / 2); //child 3
	m_pChild[3] = new Octree(vector3(m_v3Center.x - m_fSize / 4, m_v3Center.y - m_fSize / 4, m_v3Center.z - m_fSize / 4), m_fSize / 2); //child 4
	m_pChild[4] = new Octree(vector3(m_v3Center.x - m_fSize / 4, m_v3Center.y - m_fSize / 4, m_v3Center.z + m_fSize / 4), m_fSize / 2); //child 5
	m_pChild[5] = new Octree(vector3(m_v3Center.x - m_fSize / 4, m_v3Center.y + m_fSize / 4, m_v3Center.z + m_fSize / 4), m_fSize / 2); //child 6
	m_pChild[6] = new Octree(vector3(m_v3Center.x - m_fSize / 4, m_v3Center.y + m_fSize / 4, m_v3Center.z - m_fSize / 4), m_fSize / 2); //child 7
	m_pChild[7] = new Octree(vector3(m_v3Center.x + m_fSize / 4, m_v3Center.y - m_fSize / 4, m_v3Center.z + m_fSize / 4), m_fSize / 2); //child 8
	m_uChildren = 8;

		for (int j = 0; j < 8; j++)
		{
			m_pChild[j]->ConstructTree(a_nMaxLevel - 1);
			m_pChild[j]->m_uLevel = m_uMaxLevel - a_nMaxLevel;
		}
	}
	else
	{
		m_uID = m_uOctantCount;
		m_uOctantCount++;
		//check all entities and find out if they collide with octree, give leaves a list of entities in their octree, all entities in that octree are given the same dimension
		for (int i = 0; i < m_pEntityMngr->GetEntityCount(); i++)
		{
			if (IsColliding(i))
			{
				//m_EntityList.push_back(m_uID);
				//std::cout << m_uID << std::endl;
				m_pEntityMngr->GetEntity(i)->AddDimension(m_uID);
			}
		}
	}
	
}

void Simplex::Octree::AssignIDtoEntity(void)
{
}

uint Simplex::Octree::GetOctantCount(void)
{
	return uint();
}

std::vector<Octree*> Simplex::Octree::GetLeaves()
{
	return leaves;
}

void Simplex::Octree::Release(void)
{
	/*delete m_pParent;
	m_pParent = nullptr;
	if (m_uChildren > 0)
	{
		delete[] m_pChild;
		for (int i = 0; i < 8; i++)
		{
			m_pChild[i] = nullptr;
		}
	}*/
	KillBranches();

	delete m_pRoot;
	m_pRoot = nullptr;

	/*if (m_uChildren > 0)
	{
		for (int i = 0; i < m_lChild.size(); i++)
		{
			delete m_lChild[i];
			m_lChild[i] = nullptr;
		}
	}*/
}



