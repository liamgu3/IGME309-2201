#include "MyMesh.h"
#include <vector>;
void MyMesh::Init(void)
{
	m_bBinded = false;
	m_uVertexCount = 0;

	m_VAO = 0;
	m_VBO = 0;

	m_pShaderMngr = ShaderManager::GetInstance();
}
void MyMesh::Release(void)
{
	m_pShaderMngr = nullptr;

	if (m_VBO > 0)
		glDeleteBuffers(1, &m_VBO);

	if (m_VAO > 0)
		glDeleteVertexArrays(1, &m_VAO);

	m_lVertex.clear();
	m_lVertexPos.clear();
	m_lVertexCol.clear();
}
MyMesh::MyMesh()
{
	Init();
}
MyMesh::~MyMesh() { Release(); }
MyMesh::MyMesh(MyMesh& other)
{
	m_bBinded = other.m_bBinded;

	m_pShaderMngr = other.m_pShaderMngr;

	m_uVertexCount = other.m_uVertexCount;

	m_VAO = other.m_VAO;
	m_VBO = other.m_VBO;
}
MyMesh& MyMesh::operator=(MyMesh& other)
{
	if (this != &other)
	{
		Release();
		Init();
		MyMesh temp(other);
		Swap(temp);
	}
	return *this;
}
void MyMesh::Swap(MyMesh& other)
{
	std::swap(m_bBinded, other.m_bBinded);
	std::swap(m_uVertexCount, other.m_uVertexCount);

	std::swap(m_VAO, other.m_VAO);
	std::swap(m_VBO, other.m_VBO);

	std::swap(m_lVertex, other.m_lVertex);
	std::swap(m_lVertexPos, other.m_lVertexPos);
	std::swap(m_lVertexCol, other.m_lVertexCol);

	std::swap(m_pShaderMngr, other.m_pShaderMngr);
}
void MyMesh::CompleteMesh(vector3 a_v3Color)
{
	uint uColorCount = m_lVertexCol.size();
	for (uint i = uColorCount; i < m_uVertexCount; ++i)
	{
		m_lVertexCol.push_back(a_v3Color);
	}
}
void MyMesh::AddVertexPosition(vector3 a_v3Input)
{
	m_lVertexPos.push_back(a_v3Input);
	m_uVertexCount = m_lVertexPos.size();
}
void MyMesh::AddVertexColor(vector3 a_v3Input)
{
	m_lVertexCol.push_back(a_v3Input);
}
void MyMesh::CompileOpenGL3X(void)
{
	if (m_bBinded)
		return;

	if (m_uVertexCount == 0)
		return;

	CompleteMesh();

	for (uint i = 0; i < m_uVertexCount; i++)
	{
		//Position
		m_lVertex.push_back(m_lVertexPos[i]);
		//Color
		m_lVertex.push_back(m_lVertexCol[i]);
	}
	glGenVertexArrays(1, &m_VAO);//Generate vertex array object
	glGenBuffers(1, &m_VBO);//Generate Vertex Buffered Object

	glBindVertexArray(m_VAO);//Bind the VAO
	glBindBuffer(GL_ARRAY_BUFFER, m_VBO);//Bind the VBO
	glBufferData(GL_ARRAY_BUFFER, m_uVertexCount * 2 * sizeof(vector3), &m_lVertex[0], GL_STATIC_DRAW);//Generate space for the VBO

	// Position attribute
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 2 * sizeof(vector3), (GLvoid*)0);

	// Color attribute
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 2 * sizeof(vector3), (GLvoid*)(1 * sizeof(vector3)));

	m_bBinded = true;

	glBindVertexArray(0); // Unbind VAO
}
void MyMesh::Render(matrix4 a_mProjection, matrix4 a_mView, matrix4 a_mModel)
{
	// Use the buffer and shader
	GLuint nShader = m_pShaderMngr->GetShaderID("Basic");
	glUseProgram(nShader); 

	//Bind the VAO of this object
	glBindVertexArray(m_VAO);

	// Get the GPU variables by their name and hook them to CPU variables
	GLuint MVP = glGetUniformLocation(nShader, "MVP");
	GLuint wire = glGetUniformLocation(nShader, "wire");

	//Final Projection of the Camera
	matrix4 m4MVP = a_mProjection * a_mView * a_mModel;
	glUniformMatrix4fv(MVP, 1, GL_FALSE, glm::value_ptr(m4MVP));
	
	//Solid
	glUniform3f(wire, -1.0f, -1.0f, -1.0f);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glDrawArrays(GL_TRIANGLES, 0, m_uVertexCount);  

	//Wire
	glUniform3f(wire, 1.0f, 0.0f, 1.0f);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glEnable(GL_POLYGON_OFFSET_LINE);
	glPolygonOffset(-1.f, -1.f);
	glDrawArrays(GL_TRIANGLES, 0, m_uVertexCount);
	glDisable(GL_POLYGON_OFFSET_LINE);

	glBindVertexArray(0);// Unbind VAO so it does not get in the way of other objects
}
void MyMesh::AddTri(vector3 a_vBottomLeft, vector3 a_vBottomRight, vector3 a_vTopLeft)
{
	//C
	//| \
	//A--B
	//This will make the triangle A->B->C 
	AddVertexPosition(a_vBottomLeft);
	AddVertexPosition(a_vBottomRight);
	AddVertexPosition(a_vTopLeft);
}
void MyMesh::AddQuad(vector3 a_vBottomLeft, vector3 a_vBottomRight, vector3 a_vTopLeft, vector3 a_vTopRight)
{
	//C--D
	//|  |
	//A--B
	//This will make the triangle A->B->C and then the triangle C->B->D
	AddVertexPosition(a_vBottomLeft);
	AddVertexPosition(a_vBottomRight);
	AddVertexPosition(a_vTopLeft);

	AddVertexPosition(a_vTopLeft);
	AddVertexPosition(a_vBottomRight);
	AddVertexPosition(a_vTopRight);
}
void MyMesh::GenerateCube(float a_fSize, vector3 a_v3Color)
{
	if (a_fSize < 0.01f)
		a_fSize = 0.01f;

	Release();
	Init();

	float fValue = a_fSize * 0.5f;
	//3--2
	//|  |
	//0--1

	vector3 point0(-fValue,-fValue, fValue); //0
	vector3 point1( fValue,-fValue, fValue); //1
	vector3 point2( fValue, fValue, fValue); //2
	vector3 point3(-fValue, fValue, fValue); //3

	vector3 point4(-fValue,-fValue,-fValue); //4
	vector3 point5( fValue,-fValue,-fValue); //5
	vector3 point6( fValue, fValue,-fValue); //6
	vector3 point7(-fValue, fValue,-fValue); //7

	//F
	AddQuad(point0, point1, point3, point2);

	//B
	AddQuad(point5, point4, point6, point7);

	//L
	AddQuad(point4, point0, point7, point3);

	//R
	AddQuad(point1, point5, point2, point6);

	//U
	AddQuad(point3, point2, point7, point6);

	//D
	AddQuad(point4, point5, point0, point1);

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateCuboid(vector3 a_v3Dimensions, vector3 a_v3Color)
{
	Release();
	Init();

	vector3 v3Value = a_v3Dimensions * 0.5f;
	//3--2
	//|  |
	//0--1
	vector3 point0(-v3Value.x, -v3Value.y, v3Value.z); //0
	vector3 point1(v3Value.x, -v3Value.y, v3Value.z); //1
	vector3 point2(v3Value.x, v3Value.y, v3Value.z); //2
	vector3 point3(-v3Value.x, v3Value.y, v3Value.z); //3

	vector3 point4(-v3Value.x, -v3Value.y, -v3Value.z); //4
	vector3 point5(v3Value.x, -v3Value.y, -v3Value.z); //5
	vector3 point6(v3Value.x, v3Value.y, -v3Value.z); //6
	vector3 point7(-v3Value.x, v3Value.y, -v3Value.z); //7

	//F
	AddQuad(point0, point1, point3, point2);

	//B
	AddQuad(point5, point4, point6, point7);

	//L
	AddQuad(point4, point0, point7, point3);

	//R
	AddQuad(point1, point5, point2, point6);

	//U
	AddQuad(point3, point2, point7, point6);

	//D
	AddQuad(point4, point5, point0, point1);

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateCone(float a_fRadius, float a_fHeight, int a_nSubdivisions, vector3 a_v3Color)
{
	if (a_fRadius < 0.01f)
		a_fRadius = 0.01f;

	if (a_fHeight < 0.01f)
		a_fHeight = 0.01f;

	if (a_nSubdivisions < 3)
		a_nSubdivisions = 3;
	if (a_nSubdivisions > 360)
		a_nSubdivisions = 360;

	Release();
	Init();

	// Replace this with your code
	//GenerateCube(a_fRadius * 2.0f, a_v3Color);

	vector3 peak(0, a_fHeight / 2, 0);	//create peak and base of cone
	vector3 base(0, -a_fHeight / 2, 0);

	float angle = 0;
	float angleincrement = 2 * PI * (1.0 / (float)(a_nSubdivisions));

	std::vector<vector3> outerPoints;

	for (int i = 0; i < a_nSubdivisions; i++)		//create all outer points of cone and add to vector array
	{
		vector3 point(a_fRadius * cos(angle), -a_fHeight / 2, a_fRadius * sin(angle));
		outerPoints.push_back(point);
		angle += angleincrement;
	}

	for (int i = 0; i < a_nSubdivisions; i++)	//create tri's from edges to peak and edges to base
	{
		if (i != a_nSubdivisions - 1)
		{
			AddTri(outerPoints[i], outerPoints[i+1], peak);
			AddTri(outerPoints[i], base , outerPoints[i+1]);
		}
		else
		{
			AddTri(outerPoints[i], outerPoints[0], peak);
			AddTri(outerPoints[i], base , outerPoints[0]);
		}
	}
	// -------------------------------

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateCylinder(float a_fRadius, float a_fHeight, int a_nSubdivisions, vector3 a_v3Color)
{
	if (a_fRadius < 0.01f)
		a_fRadius = 0.01f;

	if (a_fHeight < 0.01f)
		a_fHeight = 0.01f;

	if (a_nSubdivisions < 3)
		a_nSubdivisions = 3;
	if (a_nSubdivisions > 360)
		a_nSubdivisions = 360;

	Release();
	Init();

	// Replace this with your code
	//GenerateCube(a_fRadius * 2.0f, a_v3Color);
	// -------------------------------
	vector3 peak(0, a_fHeight / 2, 0);	//creates center of top and bottom faces
	vector3 base(0, -a_fHeight / 2, 0);

	float angle = 0;
	float angleincrement = 2 * PI * (1.0 / (float)(a_nSubdivisions));

	std::vector<vector3> upperPoints;
	std::vector<vector3> lowerPoints;

	for (int i = 0; i < a_nSubdivisions; i++)		//creates all outer points
	{
		vector3 point(a_fRadius * cos(angle), a_fHeight / 2, a_fRadius * sin(angle));
		upperPoints.push_back(point);
		vector3 point2(a_fRadius * cos(angle), -a_fHeight / 2, a_fRadius * sin(angle));
		lowerPoints.push_back(point2);
		angle += angleincrement;
	}

	for (int i = 0; i < a_nSubdivisions; i++)	//fills in with tris and quads
	{
		if (i != a_nSubdivisions - 1)
		{
			AddTri(upperPoints[i], peak, upperPoints[i + 1]);
			AddTri(lowerPoints[i], lowerPoints[i + 1], base);
			AddQuad(upperPoints[i], upperPoints[i + 1], lowerPoints[i], lowerPoints[i + 1]);
		}
		else
		{
			AddTri(upperPoints[i], peak, upperPoints[0]);
			AddTri(lowerPoints[i], lowerPoints[0], base);
			AddQuad(upperPoints[i], upperPoints[0], lowerPoints[i], lowerPoints[0]);
		}
	}

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateTube(float a_fOuterRadius, float a_fInnerRadius, float a_fHeight, int a_nSubdivisions, vector3 a_v3Color)
{
	if (a_fOuterRadius < 0.01f)
		a_fOuterRadius = 0.01f;

	if (a_fInnerRadius < 0.005f)
		a_fInnerRadius = 0.005f;

	if (a_fInnerRadius > a_fOuterRadius)
		std::swap(a_fInnerRadius, a_fOuterRadius);

	if (a_fHeight < 0.01f)
		a_fHeight = 0.01f;

	if (a_nSubdivisions < 3)
		a_nSubdivisions = 3;
	if (a_nSubdivisions > 360)
		a_nSubdivisions = 360;

	Release();
	Init();

	// Replace this with your code
	//GenerateCube(a_fOuterRadius * 2.0f, a_v3Color);
	vector3 peak(0, a_fHeight / 2, 0);		//creates center of top and bottom faces
	vector3 base(0, -a_fHeight / 2, 0);

	float angle = 0;
	float angleincrement = 2 * PI * (1.0 / (float)(a_nSubdivisions));

	std::vector<vector3> upperOuterPoints;
	std::vector<vector3> lowerOuterPoints;
	std::vector<vector3> upperInnerPoints;
	std::vector<vector3> lowerInnerPoints;

	for (int i = 0; i < a_nSubdivisions; i++)		//creates all outer and inner points
	{
		vector3 point(a_fOuterRadius * cos(angle), a_fHeight / 2, a_fOuterRadius * sin(angle));
		upperOuterPoints.push_back(point);
		vector3 point2(a_fOuterRadius * cos(angle), -a_fHeight / 2, a_fOuterRadius * sin(angle));
		lowerOuterPoints.push_back(point2);
		vector3 point3(a_fInnerRadius * cos(angle), a_fHeight / 2, a_fInnerRadius * sin(angle));
		upperInnerPoints.push_back(point3);
		vector3 point4(a_fInnerRadius * cos(angle), -a_fHeight / 2, a_fInnerRadius * sin(angle));
		lowerInnerPoints.push_back(point4);
		angle += angleincrement;
	}

	for (int i = 0; i < a_nSubdivisions; i++)	//fills in with quads
	{
		if (i != a_nSubdivisions - 1)
		{
			AddQuad(upperOuterPoints[i], upperOuterPoints[i + 1], lowerOuterPoints[i], lowerOuterPoints[i + 1]);	//outer faces
			AddQuad(lowerInnerPoints[i], lowerInnerPoints[i + 1], upperInnerPoints[i], upperInnerPoints[i + 1]);	//inner faces
			AddQuad(upperInnerPoints[i], upperInnerPoints[i + 1], upperOuterPoints[i], upperOuterPoints[i + 1]);	//upper faces
			AddQuad(lowerOuterPoints[i], lowerOuterPoints[i + 1], lowerInnerPoints[i], lowerInnerPoints[i + 1]);	//lower faces
		}
		else
		{
			AddQuad(upperOuterPoints[i], upperOuterPoints[0], lowerOuterPoints[i], lowerOuterPoints[0]);	//outer faces
			AddQuad(lowerInnerPoints[i], lowerInnerPoints[0], upperInnerPoints[i], upperInnerPoints[0]);	//inner faces
			AddQuad(upperInnerPoints[i], upperInnerPoints[0], upperOuterPoints[i], upperOuterPoints[0]);	//upper faces
			AddQuad(lowerOuterPoints[i], lowerOuterPoints[0], lowerInnerPoints[i], lowerInnerPoints[0]);	//lower faces
		}
	}

	// -------------------------------

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateTorus(float a_fOuterRadius, float a_fInnerRadius, int a_nSubdivisionsA, int a_nSubdivisionsB, vector3 a_v3Color)
{
	if (a_fOuterRadius < 0.01f)
		a_fOuterRadius = 0.01f;

	if (a_fInnerRadius < 0.005f)
		a_fInnerRadius = 0.005f;

	if (a_fInnerRadius > a_fOuterRadius)
		std::swap(a_fInnerRadius, a_fOuterRadius);

	if (a_nSubdivisionsA < 3)
		a_nSubdivisionsA = 3;
	if (a_nSubdivisionsA > 360)
		a_nSubdivisionsA = 360;

	if (a_nSubdivisionsB < 3)
		a_nSubdivisionsB = 3;
	if (a_nSubdivisionsB > 360)
		a_nSubdivisionsB = 360;

	Release();
	Init();

	// Replace this with your code
	//GenerateCube(a_fOuterRadius * 2.0f, a_v3Color);
	float angleHor = 0;
	float angleincrementHor = 2 * PI * (1.0 / (float)(a_nSubdivisionsA));
	float angleVer = 0;
	float angleincrementVer = 2 * PI * (1.0 / (float)(a_nSubdivisionsB));

	//std::vector<vector3> firstRing;
	//std::vector<vector3> upperPoints;	//upper ring of points currently being added
	//std::vector<vector3> lowerPoints;	//lower ring of points currently being added

	std::vector<std::vector<vector3>> rings;
	std::vector<vector3> currentRing;

	for (int i = 0; i < a_nSubdivisionsA ; i++)		//creating rings of points in a vector, then adding all rings to vector of vectors
	{
		for (int j = 0; j < a_nSubdivisionsB; j++)
		{
			vector3 point((a_fOuterRadius + (a_fInnerRadius * cos(angleVer))) * cos(angleHor), (a_fOuterRadius + (a_fInnerRadius * cos(angleVer))) * sin(angleHor), a_fInnerRadius * sin(angleVer));
			currentRing.push_back(point);
			angleVer += angleincrementVer;
		}
		rings.push_back(currentRing);
		currentRing.clear();
		angleHor += angleincrementHor;
	}

	for (int i = 0; i < a_nSubdivisionsA; i++)		//connecting each ring to the one after it with quads
	{
		if (i != a_nSubdivisionsA - 1)
		{
			for (int j = 0; j < a_nSubdivisionsB; j++)
			{
				if (j != a_nSubdivisionsB - 1)
				{
					AddQuad(rings[i + 1][j], rings[i + 1][j + 1], rings[i][j], rings[i][j + 1]);
				}
				else
				{
					AddQuad(rings[i + 1][j], rings[i + 1][0], rings[i][j], rings[i][0]);
				}
			}
		}
		else
		{
			for (int j = 0; j < a_nSubdivisionsB; j++)
			{
				if (j != a_nSubdivisionsB - 1)
				{
					AddQuad(rings[0][j], rings[0][j + 1], rings[i][j], rings[i][j + 1]);
				}
				else
				{
					AddQuad(rings[0][j], rings[0][0], rings[i][j], rings[i][0]);
				}
			}
		}
	}

	// -------------------------------

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateSphere(float a_fRadius, int a_nSubdivisions, vector3 a_v3Color)
{
	if (a_fRadius < 0.01f)
		a_fRadius = 0.01f;

	//Sets minimum and maximum of subdivisions
	if (a_nSubdivisions < 1)
	{
		GenerateCube(a_fRadius * 2.0f, a_v3Color);
		return;
	}
	if (a_nSubdivisions > 6)
		a_nSubdivisions = 6;

	Release();
	Init();

	// Replace this with your code
	//GenerateCube(a_fRadius * 2.0f, a_v3Color);
	float angleHor = 0;
	float angleincrementHor = 2 * PI * (1.0 / (float)(a_nSubdivisions));
	float angleVer = 2 * a_fRadius;
	float angleincrementVer = 2 * (a_fRadius / (float)(a_nSubdivisions));

	std::vector<vector3> upperPoints;	//upper ring of points currently being added
	std::vector<vector3> lowerPoints;	//lower ring of points currently being added


	for (int i = 0; i < a_nSubdivisions * 2; i++)
	{
		

		if (i == 0)	//top layer
		{
			vector3 point(0, a_fRadius, 0);
			upperPoints.push_back(point);

			angleVer -= angleincrementVer;
			for (int j = 0; j < a_nSubdivisions; j++)
			{
				vector3 point2(sqrt((a_fRadius * a_fRadius) - ((a_fRadius - abs(angleVer)) * (a_fRadius - abs(angleVer)))) * cos(angleHor), a_fRadius - abs(angleVer), sqrt((a_fRadius * a_fRadius) - ((a_fRadius - abs(angleVer)) * (a_fRadius - abs(angleVer)))) * sin(angleHor));
				lowerPoints.push_back(point2);
				angleHor += angleincrementHor;
			}

			for (int k = 0; k < a_nSubdivisions; k++)
			{
				if (k != a_nSubdivisions - 1)
				{
					AddTri(lowerPoints[k], lowerPoints[k + 1], upperPoints[0]);
				}
				else
				{
					AddTri(lowerPoints[k], lowerPoints[0], upperPoints[0]);
				}
			}
			upperPoints = lowerPoints;
			lowerPoints.clear();
		}
		else if (i == a_nSubdivisions * 2 - 1)	//bottom layer
		{
			vector3 point3(0, -a_fRadius, 0);
			std::cout << point3.x << "," << point3.y << "," << point3.z << std::endl;
			lowerPoints.push_back(point3);

			for (int k = 0; k < a_nSubdivisions; k++)
			{
				if (k != a_nSubdivisions - 1)
				{
					AddTri(upperPoints[k], upperPoints[k + 1], point3);
				}
				else
				{
					AddTri(upperPoints[k], upperPoints[0], point3);
				}
			}
		}
		else	//middle layers
		{
			angleVer -= angleincrementVer;
			for (int j = 0; j < a_nSubdivisions; j++)
			{
				vector3 point2(sqrt((a_fRadius * a_fRadius) - ((a_fRadius - abs(angleVer)) * (a_fRadius - abs(angleVer)))) * cos(angleHor), a_fRadius - abs(angleVer), sqrt((a_fRadius * a_fRadius) - ((a_fRadius - abs(angleVer)) * (a_fRadius - abs(angleVer)))) * sin(angleHor));
				lowerPoints.push_back(point2);
				angleHor += angleincrementHor;
			}

			if (i < (a_nSubdivisions - 1))
			{
				for (int k = 0; k < a_nSubdivisions; k++)
				{
					if (k != a_nSubdivisions - 1)
					{
						AddQuad(lowerPoints[k], lowerPoints[k + 1], upperPoints[k], upperPoints[k + 1]);
					}
					else
					{
						AddQuad(lowerPoints[k], lowerPoints[0], upperPoints[k], upperPoints[0]);
					}
				}
			}
			else
			{
				for (int k = 0; k < a_nSubdivisions; k++)
				{
					if (k != a_nSubdivisions - 1)
					{
						AddQuad(upperPoints[k], upperPoints[k + 1], lowerPoints[k], lowerPoints[k + 1]);
					}
					else
					{
						AddQuad(upperPoints[k], upperPoints[0], lowerPoints[k], lowerPoints[0]);
					}
				}
			}

			upperPoints = lowerPoints;
			lowerPoints.clear();
		}
	}
	// -------------------------------

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}