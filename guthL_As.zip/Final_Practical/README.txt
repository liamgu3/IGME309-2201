I implemented physics and collisions. Whenever the seeker (steve) reaches the target (cow) the target moves to a new location and steve moves to that one next.
There is a surface of blocks forming the floor. There are miscellanous other blocks on the plane to demonstrate the collision with Steve.

The Astar is not actually working; the code is still there but commented out.
There is a much shorter method that just functions to move steve and the target around in a straight line, in order to demonstrate the non Astar parts of the project.
