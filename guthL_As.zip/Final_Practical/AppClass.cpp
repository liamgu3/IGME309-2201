#include "AppClass.h"
#include <cmath>
#include <vector>
using namespace Simplex;
void Application::InitVariables(void)
{
	//Set the position and target of the camera
	m_pCameraMngr->SetPositionTargetAndUpward(
		vector3(12.5f, 10.0f, 37.5f), //Position
		vector3(12.5f, 0.0f, 12.5f),	//Target
		AXIS_Y);					//Up

	m_pLightMngr->SetPosition(vector3(0.0f, 3.0f, 13.0f), 1); //set the position of first light (0 is reserved for ambient light)

	m_pEntityMngr->AddEntity("Minecraft\\Steve.obj", "Steve");		//creates steve object
	steve = m_pEntityMngr->GetEntity(m_pEntityMngr->GetEntityIndex("Steve"));
	vector3 v3Position = vector3(12.0f, 1.0f, 12.0f);
	matrix4 m4Position = glm::translate(v3Position);
	m_pEntityMngr->SetModelMatrix(m4Position);
	m_pEntityMngr->UsePhysicsSolver();
	
	for (int i = 0; i < 20; i++)	//creates random cubes with collision scattered on surface
	{
		m_pEntityMngr->AddEntity("Minecraft\\Cube.obj", "Cube_" + std::to_string(i));
		vector3 v3Position = vector3(glm::sphericalRand(12.0f));
		v3Position.y = 1.0f;
		v3Position.x += 12.5f;
		v3Position.z += 12.5f;
		matrix4 m4Position = glm::translate(v3Position);
		m_pEntityMngr->SetModelMatrix(m4Position * glm::scale(vector3(1.0f)));
		m_pEntityMngr->UsePhysicsSolver();
		//m_pEntityMngr->SetMass(2);

		//m_pEntityMngr->SetMass(i+1);
	}

	for (int i = 0; i < 25; i++)	//creates surface of cubes for everything else to sit on
	{
		std::vector<MyEntity*> entityList;
		gridList.push_back(entityList);
		for (int j = 0; j < 25; j++)
		{
			m_pEntityMngr->AddEntity("Minecraft\\Cube.obj", "FloorCube (" + std::to_string(i) + ", " + std::to_string(j) + ")");
			vector3 v3Position = vector3(i, -1.0f, j) * 1.0001;
			matrix4 m4Position = glm::translate(v3Position);
			m_pEntityMngr->SetModelMatrix(m4Position);
			//m_pEntityMngr->UsePhysicsSolver();

			gridList[i].push_back(m_pEntityMngr->GetEntity(m_pEntityMngr->GetEntityIndex("FloorCube (" + std::to_string(i) + ", " + std::to_string(j) + ")")));
		}
	}
	srand(time(0));

	m_pEntityMngr->AddEntity("Minecraft\\Cow.obj", "target");	//sets original target
	target = vector3(rand() % 24, 0.0f, rand() % 24);
	std::cout << target.x << ", " << target.z << std::endl;
	m4Position = glm::translate(target);
	m_pEntityMngr->SetModelMatrix(m4Position);
	m_pEntityMngr->UsePhysicsSolver();


	cow = m_pEntityMngr->GetEntity(m_pEntityMngr->GetEntityIndex("target"));

}
void Application::Update(void)
{
	//Update the system so it knows how much time has passed since the last call
	m_pSystem->Update();

	//Is the ArcBall active?
	ArcBall();

	//Is the first person camera active?
	CameraRotation();

	//Update Entity Manager
	m_pEntityMngr->Update();

	//Set the model matrix for the main object
	//m_pEntityMngr->SetModelMatrix(m_m4Steve, "Steve");

	//Add objects to render list
	m_pEntityMngr->AddEntityToRenderList(-1, true);
	//m_pEntityMngr->AddEntityToRenderList(-1, true);

	AStar();		//Astar called in update
}
void Application::Display(void)
{
	// Clear the screen
	ClearScreen();

	// draw a skybox
	m_pMeshMngr->AddSkyboxToRenderList();

	//render list call
	m_uRenderCallCount = m_pMeshMngr->Render();

	//clear the render list
	m_pMeshMngr->ClearRenderList();

	//draw gui,
	DrawGUI();

	//end the current frame (internally swaps the front and back buffers)
	m_pWindow->display();
}
void Application::Release(void)
{
	//Release MyEntityManager
	MyEntityManager::ReleaseInstance();

	//release GUI
	ShutdownGUI();
}

//		|	the not working Astar code
//		|
//		|
//	    v

//void Application::AStar(void)
//{
//	std::cout << target.x << std::endl;
//
//	if (abs(closedList[closedList.size()-1]->GetPosition() - target).length() > 1.0f)	//checks if steve has reached target
//	{
//
//		std::cout << "in here" << std::endl;
//		//if steve has reached target create new target and calculate path
//
//		target = vector3((rand() % 25) - 12.5f, 1.0f, (rand() % 25) - 12.5f);	//creates new target
//
//		//AStar pathfinding code
//
//		MyEntity* start = steve;
//		MyEntity* current = start;
//		vector3 goal = target;
//
//		closedList.push_back(start);
//		float startDist = 0;
//
//		std::vector<MyEntity*> neighbors;
//
//		while (abs(current->GetPosition() - target).length() > 2.0f)
//		{
//			neighbors.clear();
//			if (current->GetPosition().x != 0)
//				neighbors.push_back(gridList[current->GetPosition().x - 1][current->GetPosition().z]);
//			if (current->GetPosition().x != 24)
//				neighbors.push_back(gridList[current->GetPosition().x + 1][current->GetPosition().z]);
//			if (current->GetPosition().z != 0)
//				neighbors.push_back(gridList[current->GetPosition().x][current->GetPosition().z - 1]);
//			if (current->GetPosition().z != 24)
//				neighbors.push_back(gridList[current->GetPosition().x][current->GetPosition().z + 1]);
//
//			for (int i = 0; i < neighbors.size(); i++)
//			{
//				if (std::find(closedList.begin(), closedList.end(), neighbors[i]) != closedList.end())	//does nothing if vertex is already in closed set
//				{ }
//				else if (std::find(openList.begin(), openList.end(), neighbors[i]) != openList.end())	//if vertex is in open set, finds adjacecent vertex priorities
//				{
//					int newDist = current->StartDist + 1;
//					if (newDist < neighbors[i]->StartDist)
//					{
//						neighbors[i]->pathNeighbor = current;
//						neighbors[i]->StartDist = newDist;
//						neighbors[i]->goalDist = ((neighbors[i]->GetPosition().x - goal.x) + (neighbors[i]->GetPosition().z - goal.z));
//						neighbors[i]->totalDist = neighbors[i]->StartDist + neighbors[i]->goalDist;
//					}
//				}
//				else		//if not in open set, add vertex to open set
//				{
//					neighbors[i]->pathNeighbor = current;
//					neighbors[i]->StartDist = ((neighbors[i]->GetPosition().x - start->GetPosition().x) + (neighbors[i]->GetPosition().z - start->GetPosition().z));
//					neighbors[i]->goalDist = ((neighbors[i]->GetPosition().x - goal.x) + (neighbors[i]->GetPosition().z - goal.z));
//					neighbors[i]->totalDist = neighbors[i]->StartDist + neighbors[i]->goalDist;
//					openList.push_back(neighbors[i]);
//				}
//			}
//			float closest = 2000.0f;
//			MyEntity* closestEntity = steve;
//			for (int j = 0; j < neighbors.size(); j++)
//			{
//				if (neighbors[j]->totalDist < closest)
//				{
//					closest = neighbors[j]->totalDist;
//					closestEntity = neighbors[j];
//				}
//			}
//
//			current = closestEntity;
//			closedList.push_back(closestEntity);
//		}
//	}
//	else
//	{
//		//if steve has not reached target, move towards new target
//		for (int i = 0; i < closedList.size(); i++)
//		{
//			vector3 v3Position = closedList[i]->GetPosition();
//			matrix4 m4Position = glm::translate(v3Position);
//			steve->SetModelMatrix(m4Position);
//		}
//
//		openList.clear();
//		closedList.clear();
//	}
//}


//this is my fake astar code, the real astar code doesn't work, this is just so you can see that everything else is working
//it just pushes steve to the target and moves the target whenever steve reaches it
void Application::AStar(void)
{

	if (round(steve->GetPosition().x) != round(target.x) || round(steve->GetPosition().z) != round(target.z))
	{
		steve->ApplyForce((target - steve->GetPosition()) * .001f);
		//std::cout << target.x << ", " << target.z << std::endl;
		//std::cout << steve->GetPosition().x << ", " << steve->GetPosition().z << std::endl;
	}
	else
	{
		target = vector3(rand() % 24, 1.0f, rand() % 24);
		matrix4 m4Position = glm::translate(target);
		cow->SetModelMatrix(m4Position);
	}
}